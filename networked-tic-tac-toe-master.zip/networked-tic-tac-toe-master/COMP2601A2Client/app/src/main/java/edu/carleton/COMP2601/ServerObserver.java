package edu.carleton.COMP2601;

import java.util.ArrayList;

/**
 * Created by Hrishi Mukherjee on 2017-02-12.
 */

public interface ServerObserver {

    public void update(ArrayList<String> updatedUsers);

}
