package communication;

public interface EventHandler {
	public void handleEvent(Event event);
}
