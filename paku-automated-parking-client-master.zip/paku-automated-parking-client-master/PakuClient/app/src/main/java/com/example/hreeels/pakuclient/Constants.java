package com.example.hreeels.pakuclient;

/**
 * Created by Hreeels on 2016-03-19.
 */
public class Constants {

    public static String SERVER_DEFAULT_PATH = "http://192.168.1.110:2116";

    private Constants() {
        throw new AssertionError();
    }

}
