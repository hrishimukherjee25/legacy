## pourquoi
##### wide;
sac-le-couer

### short:

champselysees

saintgermain

##### short:

.jp
tel

### Long:

.no
let 

.fr
</it MOULIN ROUGE>

.in
fold

.nl
commerce

.fr

it's not funny, it's the law!

attention! {/madame-jeanette}
