//
//  Constants.swift
//  Kanto Client
//
//  Created by Haamed Sultani on 2017-03-30.
//  Copyright © 2017 Haamed Sultani. All rights reserved.
//

import Foundation

struct Constants
{
    static let HOST: String = "http://172.17.49.204:8080/KANTO/rest/engine"
    static let APIKEY: String = "AIzaSyCP67aqkfbH5W5ZtAYDp6UCXNxoH506zhE" //used for youtube API
}
