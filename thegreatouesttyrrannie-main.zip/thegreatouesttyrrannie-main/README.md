# thegreatouesttyrrannie
_splashdown_

.
.

--_battle_--

**SORT**

**PARSE**

**GENERATE**

**SUGGEST**

*PLAY*

--_population delegation_--

*PIECEWISE BACKPROPAGATE*

**ATTAIN** _coefficient gradient_

**GAIN** _gain function_

*MAIN*

**U**

**B**
